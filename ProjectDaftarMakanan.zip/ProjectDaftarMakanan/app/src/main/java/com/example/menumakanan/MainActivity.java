package com.example.menumakanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> FotoMakanan = new ArrayList<>();
    private ArrayList<String> NamaMakanan = new ArrayList<>();
    private ArrayList<String> InfoMakanan = new ArrayList<>();
    private ArrayList<String> HargaMakanan = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getDataFromInternet();
    }

    private void prosesRecyclerViewAdapter(){
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(FotoMakanan, NamaMakanan, InfoMakanan, HargaMakanan,this);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    private void getDataFromInternet(){
        NamaMakanan.add("Ayam Penyet");
        FotoMakanan.add("https://i2.wp.com/resepkoki.id/wp-content/uploads/2017/04/Resep-Ayam-penyet.jpg?fit=2221%2C2221&ssl=1");
        InfoMakanan.add("Ayam penyet merupakan salah satu olahan ayam goreng yang disukai oleh pecinta pedas. Asin gurihnya ayam goreng dipenyet atau ditekan dengan ulegan dengan sambal yang super pedas. Nikmatnya bikin nagih!");
        HargaMakanan.add("Harga : Rp 55.000");

        NamaMakanan.add("Babat Gongso Semarang");
        FotoMakanan.add("https://www.ayosemarang.com/images-semarang/post/articles/2020/04/30/56239/babat-gongso.jpg");
        InfoMakanan.add("Babat gongso selalu dijual bersama nasi goreng babat. Sajian babat gongso Semarang ini memakai babat hitam dengan bumbu yang pedas manis. Babat gongso Semarang dijajakan oleh penjual nasi goreng babat. Sebenarnya babat gongso merupakan tumisan babat dan bumbu sebelum diaduk dengan nasi. Orang-orang menikmati babat gongso dengan nasi putih hangat.");
        HargaMakanan.add("Harga : Rp 25.000");

        NamaMakanan.add("Sate Padang");
        FotoMakanan.add("https://i.ytimg.com/vi/Uj9SCKvkjtk/maxresdefault.jpg");
        InfoMakanan.add("Ciri khas utama sate ini bisa dilihat dari warna bumbunya yang kuning cerah. Warna kuning bumbu sate padang berasal dari kunyit yang digunakan dalam jumlah banyak.\n" +
                "\n" +
                "Bumbu kuning bertekstur kental ini juga memiliki rasa pedas dan gurih. Penggunaan bumbu dan rempah dalam jumlah banyak menjadikan rasa bumbunya sedap. Bumbu inilah yang membuat daging sate ini lebih lezat.");
        HargaMakanan.add("Harga : Rp 30.000");

        NamaMakanan.add("Sop Kambing");
        FotoMakanan.add("https://makananoleholeh.com/wp-content/uploads/2017/07/Sop-Kambing-Khas-Indonesia.jpg");
        InfoMakanan.add("Sebagai binatang yang sangat melimpah di Indonesia, olahan dengan bahan utama daging kambing begitu menjamur di Tanah Air, salah satunya adalah sop kambing.\n" +
                "\n" +
                "Bahan utamanya sudah pasti daging kambing yang diiris dalam bentuk kecil, baru nantinya disajikan bersama dengan kuahnya bewarna bening kekuningan.");
        HargaMakanan.add("Harga : Rp 35.000");

        NamaMakanan.add("Otak-otak");
        FotoMakanan.add("https://makananoleholeh.com/wp-content/uploads/2017/07/Otak-otak-Khas-Indonesia.jpg");
        InfoMakanan.add("Makanan ini secara umumnya dibuat menggunakan daging ikan tenggiri, ingat dagingnya saja yang dipakai.\n" +
                "\n" +
                "Daging tersebut akan dicampur dengan aneka bumbu sebelum nantinya dibungkus menggunakan daun pisang untuk selanjutnya dipanggang.\n");
        HargaMakanan.add("Harga : Rp 30.000");

        NamaMakanan.add("Betutu");
        FotoMakanan.add("https://makananoleholeh.com/wp-content/uploads/2017/07/Betutu-Khas-Indonesia.jpg");
        InfoMakanan.add("Betutu merupakan sejenis cara pengolahan makanan dengan cara memanggangnya pada api sekam, biasanya yang dipakai adalah ayam dan bebek.\n" +
                "\n" +
                "Bahkan ayam dan bebek ini harus dipanggang dalam keadaan utuh, namun sebelumnya harus dibumbui dengan bumbu base genep khas Bali, karena di sanalah tempat asalnya.");
        HargaMakanan.add("Harga : Rp 55.000");

        NamaMakanan.add("Bakso");
        FotoMakanan.add("https://cdns.klimg.com/merdeka.com/i/w/news/2020/06/03/1183187/content_images/670x335/20200603090554-1-ilustrasi-bakso-urat-001-tantri-setyorini.jpg");
        InfoMakanan.add("Bakso merupakan makanan yang sangat mudah kita jumpai di setiap daerah di Indonesia. Makanan yang terbuat dari bola daging dengan kuah gurih dan berbagai bahan pelengkap ini sangat digemari di Indonesia bahkan mancanegara.\n" +
                "\n" +
                "Kini, kita juga dengan mudah menjumpai bakso di berbagai restaurant Indonesia yang ada di luar negeri.");
        HargaMakanan.add("Harga : Rp 15.000");

        prosesRecyclerViewAdapter();
    }
}